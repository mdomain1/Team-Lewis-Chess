/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chessapplication;
//imports 
import javafx.scene.control.Skin;
import javafx.scene.control.SkinBase;

//class definition 
class CustomControlSkin extends SkinBase<CustomControl> implements Skin<CustomControl> {
	public CustomControlSkin(CustomControl cc) {
		//call the super class constructor
		super(cc);
	}
}
